<?php
require_once "../_config/config.php";
require "../_assets/libs/vendor/autoload.php";

// Check if 'id' parameter is set in GET request
if (isset($_GET['id'])) {
    $id_obat = $_GET['id'];

    // Use prepared statement to prevent SQL injection
    $stmt = $con->prepare("DELETE FROM tb_obat WHERE id_obat = ?");
    if (!$stmt) {
        echo "<script>alert('Gagal menyiapkan query. Silakan coba lagi'); window.location='data.php';</script>";
        exit();
    }

    $stmt->bind_param("i", $id_obat);  // Bind the ID parameter to the query (integer type)

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script>alert('Data berhasil dihapus'); window.location='data.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data. Silakan coba lagi'); window.location='data.php';</script>";
    }

    // Close the prepared statement
    $stmt->close();
} else {
    echo "<script>alert('ID tidak ditemukan'); window.location='data.php';</script>";
}
?>
